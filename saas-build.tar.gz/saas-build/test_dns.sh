#!/bin/sh
# Test DNS and connectivity from web container
echo "=== DNS test ==="
docker exec zscx-saas-web sh -c 'wget -q -O- http://server:3000/api/auth/login --post-data="{\"username\":\"admin\",\"password\":\"admin123\"}" --header="Content-Type: application/json" 2>&1' | head -c 500

echo ""
echo "=== Ping server ==="
docker exec zscx-saas-web sh -c 'ping -c 1 server 2>&1'