export const ROLE_LABELS: Record<string, string> = {
  ADMIN: '超级管理员', MANAGER: '管理员', USER: '录入员', VIEWER: '查看员',
}

export const RECORD_STATUS_LABELS: Record<string, string> = {
  DRAFT: '草稿', SUBMITTED: '已提交', REVIEWED: '已审核', REJECTED: '已驳回', ARCHIVED: '已归档',
}

export const RECORD_STATUS_COLORS: Record<string, string> = {
  DRAFT: 'bg-gray-100 text-gray-600', SUBMITTED: 'bg-blue-100 text-blue-600',
  REVIEWED: 'bg-green-100 text-green-600', REJECTED: 'bg-red-100 text-red-600',
  ARCHIVED: 'bg-gray-200 text-gray-500',
}

export const CACHE_KEYS = {
  USER_SESSION: 'session:', USER_PERMISSIONS: 'perm:',
  TENANT_CONFIG: 'tenant:', NOTIFICATION_LOCK: 'notify:lock:',
  APPROVAL_CACHE: 'approval:',
}