import { z } from 'zod'

export const CHANNEL_LABELS: Record<string, string> = {
  WECOM: '企业微信', DINGTALK: '钉钉', FEISHU: '飞书', WECHAT: '微信', EMAIL: '邮件',
}

export const APPROVER_TYPE_LABELS: Record<string, string> = {
  ROLE: '指定角色', DEPARTMENT_HEAD: '部门负责人', SPECIFIC_USER: '指定用户',
}

export const APPROVAL_ACTION_LABELS: Record<string, string> = {
  APPROVED: '通过', REJECTED: '驳回', RETURNED: '退回修改',
}

export const wecomConfigSchema = z.object({
  corpId: z.string().min(1), agentId: z.string().min(1), secret: z.string().min(1),
})
export const dingtalkConfigSchema = z.object({
  appKey: z.string().min(1), appSecret: z.string().min(1), webhookUrl: z.string().optional(),
})
export const feishuConfigSchema = z.object({
  appId: z.string().min(1), appSecret: z.string().min(1), webhookUrl: z.string().optional(),
})
export const wechatConfigSchema = z.object({
  appId: z.string().min(1), appSecret: z.string().min(1), templateId: z.string().optional(),
})
export const emailConfigSchema = z.object({
  smtpHost: z.string().min(1), smtpPort: z.number(), smtpUser: z.string().min(1), smtpPass: z.string().min(1),
})

export type WeComConfig = z.infer<typeof wecomConfigSchema>
export type DingTalkConfig = z.infer<typeof dingtalkConfigSchema>
export type FeishuConfig = z.infer<typeof feishuConfigSchema>
export type WeChatConfig = z.infer<typeof wechatConfigSchema>
export type EmailConfig = z.infer<typeof emailConfigSchema>