import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')
  const tenant = await prisma.tenant.upsert({
    where: { code: 'default' },
    update: {},
    create: { name: '默认租户', code: 'default' },
  })

  const roles = [
    { name: 'ADMIN', label: '超级管理员', canManageTables: true, canManageUsers: true, canManagePermissions: true, canManageTemplates: true, canManageDepartments: true, canManageApproval: true, canManageSettings: true, canViewLogs: true, isSystem: true, sortOrder: 1 },
    { name: 'MANAGER', label: '管理员', canManageTables: true, canManageUsers: true, canManagePermissions: true, canManageTemplates: true, canManageDepartments: false, canManageApproval: true, canManageSettings: false, canViewLogs: true, isSystem: true, sortOrder: 2 },
    { name: 'USER', label: '录入员', canManageTables: false, canManageUsers: false, canManagePermissions: false, canManageTemplates: false, canManageDepartments: false, canManageApproval: false, canManageSettings: false, canViewLogs: false, isSystem: true, sortOrder: 3 },
    { name: 'VIEWER', label: '查看员', canManageTables: false, canManageUsers: false, canManagePermissions: false, canManageTemplates: false, canManageDepartments: false, canManageApproval: false, canManageSettings: false, canViewLogs: false, isSystem: true, sortOrder: 4 },
  ]

  const createdRoles: Record<string, any> = {}
  for (const role of roles) {
    const r = await prisma.role.upsert({ where: { name: role.name }, update: role, create: role })
    createdRoles[role.name] = r
  }

  const passwordHash = await bcrypt.hash('admin123', 10)
  await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: { username: 'admin', passwordHash, realName: '系统管理员', phone: '13800000000', roleId: createdRoles.ADMIN.id, tenantId: tenant.id, status: 'ACTIVE' },
  })

  console.log('Seed completed!')
  console.log('  Default admin: admin / admin123')
  console.log('  Tenant: default')
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => prisma.$disconnect())