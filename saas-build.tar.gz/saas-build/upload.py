import paramiko

host = '192.168.0.7'
user = 'zhaowei'
pw = 'Thomas009865'

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, 22, user, pw)

print('Building...')
stdin, stdout, stderr = ssh.exec_command(
    'cd /vol3/1000/docker/zscx-saas/saas-build '
    '&& DOCKER_CONFIG=/vol3/1000/docker/zscx-saas/.docker-cache '
    'docker compose -f docker-compose.yml build 2>&1'
)
out = stdout.read().decode()
err = stderr.read().decode()
print(out[-6000:] if len(out) > 6000 else out)
if err:
    print('ERR:', err[-1000:] if len(err) > 1000 else err)

ssh.close()