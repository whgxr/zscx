export default function ApprovalCenterPage() {
  const tabs = ['待审批', '已审批', '我提交的']
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">审批中心</h1>
      <div className="flex gap-2 mb-4 bg-white rounded-lg p-1 shadow-sm">
        {tabs.map(tab => <button key={tab} className="flex-1 py-2 text-sm rounded-md hover:bg-gray-100">{tab}</button>)}
      </div>
      <div className="bg-white rounded-xl p-6 shadow-sm text-center text-gray-400">暂无审批记录</div>
    </div>
  )
}