export default function SettingsPage() {
  const menuItems = [
    { label: '组织架构', href: '/settings/departments' },
    { label: '项目管理', href: '/settings/projects' },
    { label: '审批配置', href: '/settings/approval' },
    { label: '通知配置', href: '/settings/notifications' },
    { label: '权限管理', href: '/settings/permissions' },
    { label: '系统设置', href: '/settings/system' },
  ]
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">设置</h1>
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {menuItems.map((item, i) => (
          <a key={item.href} href={item.href} className={`flex items-center justify-between px-4 py-3 hover:bg-gray-50 ${i > 0 ? 'border-t' : ''}`}>
            <span className="text-sm">{item.label}</span><span className="text-gray-300">{'>'}</span>
          </a>
        ))}
      </div>
      <div className="mt-6"><button className="w-full py-3 bg-red-50 text-red-500 text-sm rounded-xl">退出登录</button></div>
    </div>
  )
}