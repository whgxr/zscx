export default function ProjectsPage() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">我的项目</h1>
      <div className="bg-white rounded-xl p-6 shadow-sm text-center text-gray-400">请先配置数据表后查看</div>
    </div>
  )
}