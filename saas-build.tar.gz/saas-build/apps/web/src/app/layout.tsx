import type { Metadata } from 'next'
import './globals.css'
export const metadata: Metadata = { title: 'ZSCX SaaS - 管理后台', description: '房屋征收调查系统' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="zh-CN"><body className="bg-gray-50 min-h-screen">{children}</body></html>)
}