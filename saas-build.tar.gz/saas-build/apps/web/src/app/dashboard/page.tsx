export default function DashboardPage() {
  const stats = [
    { label: '用户数', value: '--', color: 'bg-blue-500' },
    { label: '项目数', value: '--', color: 'bg-green-500' },
    { label: '部门数', value: '--', color: 'bg-purple-500' },
    { label: '记录数', value: '--', color: 'bg-orange-500' },
  ]
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">系统概览</h2>
      <div className="grid grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="bg-white rounded-xl p-4 shadow-sm">
            <div className={`w-3 h-3 rounded-full ${s.color} mb-2`} />
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-sm text-gray-500">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <h3 className="text-base font-semibold mb-4">快速入口</h3>
        <div className="grid grid-cols-3 gap-4">
          <a href="/dashboard/departments" className="p-4 border rounded-xl hover:border-blue-500 hover:bg-blue-50"><h4 className="font-medium">组织架构</h4><p className="text-sm text-gray-500 mt-1">管理部门组织结构</p></a>
          <a href="/dashboard/projects" className="p-4 border rounded-xl hover:border-blue-500 hover:bg-blue-50"><h4 className="font-medium">项目管理</h4><p className="text-sm text-gray-500 mt-1">创建和管理数据项目</p></a>
          <a href="/dashboard/notifications" className="p-4 border rounded-xl hover:border-blue-500 hover:bg-blue-50"><h4 className="font-medium">通知配置</h4><p className="text-sm text-gray-500 mt-1">配置微信/钉钉/飞书通知</p></a>
        </div>
      </div>
    </div>
  )
}