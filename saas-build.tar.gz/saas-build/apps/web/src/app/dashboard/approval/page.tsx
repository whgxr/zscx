export default function ApprovalPage() {
  return (
    <div>
      <div className="mb-6"><h2 className="text-xl font-bold">审批流程</h2><p className="text-sm text-gray-500">为数据表配置审批流程，支持多级审批</p></div>
      <div className="bg-white rounded-xl shadow-sm p-6 text-center text-gray-400">
        <p>审批流程配置</p>
        <p className="text-sm mt-2">支持：指定角色审批、部门负责人审批、指定用户审批</p>
      </div>
    </div>
  )
}