'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter, usePathname } from 'next/navigation'
import { Building2, Users, Shield, Bell, GitBranch, Database, Settings, LogOut } from 'lucide-react'

const navItems = [
  { href: '/dashboard', label: '概览', icon: Building2 },
  { href: '/dashboard/departments', label: '组织架构', icon: Users },
  { href: '/dashboard/projects', label: '项目管理', icon: Database },
  { href: '/dashboard/approval', label: '审批流程', icon: GitBranch },
  { href: '/dashboard/notifications', label: '通知配置', icon: Bell },
  { href: '/dashboard/permissions', label: '权限管理', icon: Shield },
  { href: '/dashboard/settings', label: '系统设置', icon: Settings },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const [user, setUser] = useState<{ realName: string; role: { label: string } } | null>(null)

  useEffect(() => {
    fetch('/api/auth/me').then(async res => {
      if (res.ok) {
        const data = await res.json()
        setUser(data.user)
      } else {
        router.push('/')
      }
    }).catch(() => router.push('/'))
  }, [router])

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/')
  }

  return (
    <div className="flex h-screen">
      <aside className="w-60 bg-white border-r flex flex-col">
        <div className="p-4 border-b">
          <h1 className="text-lg font-bold">ZSCX SaaS</h1>
          <p className="text-xs text-gray-400">房屋征收调查系统</p>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {navItems.map(item => { const Icon = item.icon; return (
            <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors ${pathname === item.href ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}>
              <Icon className="w-4 h-4" />{item.label}
            </Link>
          )})}
        </nav>
        <div className="p-3 border-t">
          {user && (
            <div className="px-3 py-2 mb-2 text-xs text-gray-500">
              <p className="font-medium text-gray-700">{user.realName}</p>
              <p>{user.role?.label}</p>
            </div>
          )}
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2 text-sm text-red-500 rounded-lg hover:bg-red-50 w-full">
            <LogOut className="w-4 h-4" />退出登录
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto p-6 bg-gray-50">{children}</main>
    </div>
  )
}