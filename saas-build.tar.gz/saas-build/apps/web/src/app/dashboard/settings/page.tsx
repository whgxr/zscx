export default function SettingsPage() {
  return (<div><div className="mb-6"><h2 className="text-xl font-bold">系统设置</h2><p className="text-sm text-gray-500">租户级系统配置</p></div><div className="bg-white rounded-xl shadow-sm p-6 text-center text-gray-400">系统设置</div></div>)
}