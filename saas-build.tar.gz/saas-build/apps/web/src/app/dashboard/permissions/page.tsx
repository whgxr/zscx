export default function PermissionsPage() {
  return (<div><div className="mb-6"><h2 className="text-xl font-bold">权限管理</h2><p className="text-sm text-gray-500">管理用户角色和表级权限</p></div><div className="bg-white rounded-xl shadow-sm p-6 text-center text-gray-400">权限管理将通过 API 加载</div></div>)
}