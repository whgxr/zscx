export default function ProjectsPage() {
  return (<div><div className="mb-6"><h2 className="text-xl font-bold">项目管理</h2><p className="text-sm text-gray-500">创建和管理数据表/项目</p></div><div className="bg-white rounded-xl shadow-sm p-6 text-center text-gray-400">项目列表将通过 API 加载</div></div>)
}