'use client'

import { useState, useEffect } from 'react'
import { Power, Settings, Loader2, CheckCircle } from 'lucide-react'

const channelMeta: Record<string, { label: string; desc: string; icon: string; fields: { key: string; label: string; type: string; placeholder: string }[] }> = {
  WECOM: { label: '企业微信', desc: '通过企业微信应用发送工作通知', icon: '🔷', fields: [
    { key: 'corpId', label: '企业ID (CorpId)', type: 'text', placeholder: 'ww...' },
    { key: 'agentId', label: '应用ID (AgentId)', type: 'text', placeholder: '1000001' },
    { key: 'secret', label: '应用Secret', type: 'password', placeholder: '****' },
  ]},
  DINGTALK: { label: '钉钉', desc: '通过钉钉机器人或工作通知发送消息', icon: '🔶', fields: [
    { key: 'appKey', label: 'AppKey', type: 'text', placeholder: 'ding...' },
    { key: 'appSecret', label: 'AppSecret', type: 'password', placeholder: '****' },
    { key: 'webhookUrl', label: '机器人Webhook（可选）', type: 'text', placeholder: 'https://oapi.dingtalk.com/robot/send...' },
  ]},
  FEISHU: { label: '飞书', desc: '通过飞书机器人发送交互式卡片消息', icon: '🔵', fields: [
    { key: 'appId', label: 'App ID', type: 'text', placeholder: 'cli_...' },
    { key: 'appSecret', label: 'App Secret', type: 'password', placeholder: '****' },
    { key: 'webhookUrl', label: '机器人Webhook（可选）', type: 'text', placeholder: 'https://open.feishu.cn/...' },
  ]},
  WECHAT: { label: '微信', desc: '通过公众号模板消息或小程序订阅消息', icon: '🟢', fields: [
    { key: 'appId', label: 'AppID', type: 'text', placeholder: 'wx...' },
    { key: 'appSecret', label: 'AppSecret', type: 'password', placeholder: '****' },
    { key: 'templateId', label: '模板消息ID（可选）', type: 'text', placeholder: '用于公众号模板消息' },
  ]},
  EMAIL: { label: '邮件', desc: '通过SMTP邮件服务器发送通知', icon: '📧', fields: [
    { key: 'smtpHost', label: 'SMTP服务器', type: 'text', placeholder: 'smtp.example.com' },
    { key: 'smtpPort', label: '端口', type: 'number', placeholder: '587' },
    { key: 'smtpUser', label: '邮箱账号', type: 'text', placeholder: 'user@example.com' },
    { key: 'smtpPass', label: '邮箱密码/授权码', type: 'password', placeholder: '****' },
  ]},
}

export default function NotificationsPage() {
  const [channels, setChannels] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [testing, setTesting] = useState<string | null>(null)
  const [activeChannel, setActiveChannel] = useState<string | null>(null)
  const [configForms, setConfigForms] = useState<Record<string, any>>({})

  useEffect(() => {
    fetch('/api/notifications/config')
      .then(r => r.json())
      .then(data => {
        setChannels(data.channels || [])
        const forms: Record<string, any> = {}
        data.channels?.forEach((ch: any) => { forms[ch.name] = ch.config || {} })
        setConfigForms(forms)
      })
      .finally(() => setLoading(false))
  }, [])

  const handleToggle = async (channel: string, enabled: boolean) => {
    setSaving(channel)
    await fetch('/api/notifications/config', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channel, isEnabled: enabled, config: configForms[channel] }),
    })
    setChannels(prev => prev.map(ch => ch.name === channel ? { ...ch, isEnabled: enabled } : ch))
    setSaving(null)
  }

  const handleSaveConfig = async (channel: string) => {
    setSaving(channel)
    await fetch('/api/notifications/config', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channel, isEnabled: channels.find(c => c.name === channel)?.isEnabled, config: configForms[channel] }),
    })
    setSaving(null); setActiveChannel(null)
  }

  const handleTest = async (channel: string) => {
    setTesting(channel)
    const res = await fetch('/api/notifications/test', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channel, config: configForms[channel] }),
    })
    const data = await res.json()
    alert(data.success ? `测试成功: ${data.message}` : `测试失败: ${data.message}`)
    setTesting(null)
  }

  if (loading) return <div className="p-8 text-center text-gray-400">加载中...</div>

  return (
    <div>
      <div className="mb-6"><h2 className="text-xl font-bold">通知配置</h2><p className="text-sm text-gray-500">配置多渠道通知，数据提交后自动推送到对应平台</p></div>
      <div className="space-y-4">
        {channels.map((ch: any) => {
          const meta = channelMeta[ch.name] || { label: ch.name, desc: '', icon: '📌', fields: [] }
          return (
            <div key={ch.name} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{meta.icon}</span>
                  <div><h3 className="font-medium">{meta.label}</h3><p className="text-sm text-gray-500">{meta.desc}</p></div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setActiveChannel(activeChannel === ch.name ? null : ch.name)} className="px-3 py-1.5 text-sm border rounded-lg hover:bg-gray-50 flex items-center gap-1"><Settings className="w-3.5 h-3.5" />配置</button>
                  <button onClick={() => handleToggle(ch.name, !ch.isEnabled)} disabled={saving === ch.name}
                    className={`px-3 py-1.5 text-sm rounded-lg flex items-center gap-1 ${ch.isEnabled ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {saving === ch.name ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Power className="w-3.5 h-3.5" />}
                    {ch.isEnabled ? '已启用' : '已禁用'}
                  </button>
                </div>
              </div>
              {activeChannel === ch.name && (
                <div className="border-t p-4 bg-gray-50">
                  <div className="space-y-3">
                    {meta.fields.map(f => (
                      <div key={f.key}>
                        <label className="text-sm font-medium">{f.label}</label>
                        <input type={f.type === 'password' ? 'password' : 'text'} className="w-full h-10 px-3 text-sm border rounded-lg mt-1" placeholder={f.placeholder}
                          value={configForms[ch.name]?.[f.key] || ''}
                          onChange={e => setConfigForms({ ...configForms, [ch.name]: { ...configForms[ch.name], [f.key]: e.target.value } })} />
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button onClick={() => handleSaveConfig(ch.name)} disabled={saving === ch.name} className="px-4 py-2 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center gap-1">
                      {saving === ch.name ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle className="w-3.5 h-3.5" />}保存配置
                    </button>
                    <button onClick={() => handleTest(ch.name)} disabled={testing === ch.name} className="px-4 py-2 text-sm border rounded-lg hover:bg-gray-100 flex items-center gap-1">
                      {testing === ch.name ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}测试连接
                    </button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}