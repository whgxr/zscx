'use client'
import { useEffect, useState, useCallback } from 'react'
import { Plus, Trash2, Users, ChevronRight, ChevronDown, X } from 'lucide-react'

interface Department {
  id: number
  name: string
  parentId: number | null
  managerId: number | null
  sortOrder: number
  manager: { id: number; realName: string } | null
  _count: { users: number }
  children: Department[]
}

export default function DepartmentsPage() {
  const [departments, setDepartments] = useState<Department[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [form, setForm] = useState({ name: '', parentId: '' })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const fetchDepartments = useCallback(async () => {
    try {
      const res = await fetch('/api/departments')
      if (res.ok) {
        const data = await res.json()
        setDepartments(data.departments || [])
      }
    } catch { /* ignore */ }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { fetchDepartments() }, [fetchDepartments])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim()) return
    setSubmitting(true)
    setError('')
    try {
      const res = await fetch('/api/departments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: form.name.trim(), parentId: form.parentId ? Number(form.parentId) : null }),
      })
      if (res.ok) {
        setShowModal(false)
        setForm({ name: '', parentId: '' })
        fetchDepartments()
      } else {
        const data = await res.json()
        setError(data.message || '创建失败')
      }
    } catch {
      setError('网络错误')
    } finally { setSubmitting(false) }
  }

  const toggleExpand = (id: number) => {
    setExpanded(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }

  const renderDept = (dept: Department, depth: number = 0): React.ReactNode => {
    const isExpanded = expanded.has(dept.id)
    const hasChildren = dept.children && dept.children.length > 0
    return (
      <div key={dept.id}>
        <div className="flex items-center gap-2 py-2.5 px-3 hover:bg-gray-50 rounded-lg group" style={{ paddingLeft: 16 + depth * 24 }}>
          {hasChildren ? (
            <button onClick={() => toggleExpand(dept.id)} className="text-gray-400 hover:text-gray-600">
              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
          ) : <span className="w-4" />}
          <Users className="w-4 h-4 text-blue-500" />
          <span className="flex-1 text-sm font-medium">{dept.name}</span>
          <span className="text-xs text-gray-400">{dept._count?.users || 0}人</span>
          {dept.manager && <span className="text-xs text-gray-400">{dept.manager.realName}</span>}
          <button className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 p-1">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
        {hasChildren && isExpanded && dept.children.map(child => renderDept(child, depth + 1))}
      </div>
    )
  }

  const getAllDepts = (depts: Department[]): { id: number; name: string; indent: string }[] => {
    const result: { id: number; name: string; indent: string }[] = []
    const walk = (list: Department[], depth: number) => {
      list.forEach(d => {
        result.push({ id: d.id, name: d.name, indent: '  '.repeat(depth) })
        if (d.children) walk(d.children, depth + 1)
      })
    }
    walk(depts, 0)
    return result
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold">组织架构</h2>
          <p className="text-sm text-gray-500">管理部门的树形结构和人员</p>
        </div>
        <button
          onClick={() => { setShowModal(true); setError('') }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600"
        >
          <Plus className="w-4 h-4" />新增部门
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-4">
        {loading ? (
          <p className="text-center text-gray-400 py-8">加载中...</p>
        ) : departments.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            <p>暂无部门，请点击上方"新增部门"创建</p>
          </div>
        ) : (
          <div className="border rounded-lg divide-y">
            {departments.map(dept => renderDept(dept))}
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold">新增部门</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">部门名称</label>
                <input
                  type="text" value={form.name} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-2.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="请输入部门名称" required autoFocus
                />
              </div>
              {departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">上级部门</label>
                  <select
                    value={form.parentId} onChange={e => setForm(prev => ({ ...prev, parentId: e.target.value }))}
                    className="w-full px-4 py-2.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">无（顶级部门）</option>
                    {getAllDepts(departments).map(d => (
                      <option key={d.id} value={d.id}>{d.indent}{d.name}</option>
                    ))}
                  </select>
                </div>
              )}
              {error && <p className="text-sm text-red-500">{error}</p>}
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-2.5 border rounded-lg text-sm text-gray-600 hover:bg-gray-50">取消</button>
                <button type="submit" disabled={submitting} className="flex-1 py-2.5 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600 disabled:opacity-50">
                  {submitting ? '创建中...' : '确认创建'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}