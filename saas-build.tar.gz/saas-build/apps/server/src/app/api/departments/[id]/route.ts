import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const { name, parentId, managerId, sortOrder } = await req.json()
  const dept = await prisma.department.update({
    where: { id: parseInt(params.id) },
    data: { name, parentId: parentId || null, managerId: managerId || null, sortOrder },
  })
  return NextResponse.json({ department: dept })
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const id = parseInt(params.id)
  const childCount = await prisma.department.count({ where: { parentId: id } })
  if (childCount > 0) return NextResponse.json({ message: '请先删除子部门' }, { status: 400 })
  await prisma.department.delete({ where: { id } })
  return NextResponse.json({ success: true })
}