import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ message: '未登录' }, { status: 401 })
  const depts = await prisma.department.findMany({
    where: { tenantId: user.tenantId },
    orderBy: { sortOrder: 'asc' },
    include: { manager: { select: { id: true, realName: true } }, _count: { select: { users: true } } },
  })
  return NextResponse.json({ departments: buildTree(depts) })
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const { name, parentId, managerId, sortOrder } = await req.json()
  if (!name) return NextResponse.json({ message: '部门名称不能为空' }, { status: 400 })
  const dept = await prisma.department.create({
    data: { tenantId: user.tenantId, name, parentId: parentId || null, managerId: managerId || null, sortOrder: sortOrder || 0 },
  })
  return NextResponse.json({ department: dept })
}

function buildTree(list: any[]) {
  const map = new Map(); const roots: any[] = []
  list.forEach(item => { map.set(item.id, { ...item, children: [] }) })
  list.forEach(item => {
    const node = map.get(item.id)
    if (item.parentId && map.has(item.parentId)) map.get(item.parentId).children.push(node)
    else roots.push(node)
  })
  return roots
}