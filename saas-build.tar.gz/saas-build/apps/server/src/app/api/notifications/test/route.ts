import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'

const CHANNEL_TEST_URLS: Record<string, string> = {
  WECOM: 'https://qyapi.weixin.qq.com/cgi-bin/gettoken',
  FEISHU: 'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
  WECHAT: 'https://api.weixin.qq.com/cgi-bin/token',
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const { channel, config } = await req.json()

  try {
    if (channel === 'DINGTALK' && config.webhookUrl) {
      const res = await fetch(config.webhookUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ msgtype: 'text', text: { content: '连接测试' } }),
      })
      const data = await res.json()
      return NextResponse.json(data.errcode === 0 ? { success: true, message: '钉钉连接成功' } : { success: false, message: data.errmsg })
    }
    if (channel === 'WECOM') {
      const { corpId, secret } = config
      const res = await fetch(`${CHANNEL_TEST_URLS.WECOM}?corpid=${corpId}&corpsecret=${secret}`)
      const data = await res.json()
      return NextResponse.json(data.errcode === 0 ? { success: true, message: '企业微信连接成功' } : { success: false, message: data.errmsg })
    }
    if (channel === 'FEISHU') {
      const { appId, appSecret } = config
      const res = await fetch(CHANNEL_TEST_URLS.FEISHU, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
      })
      const data = await res.json()
      return NextResponse.json(data.tenant_access_token ? { success: true, message: '飞书连接成功' } : { success: false, message: data.msg })
    }
    if (channel === 'WECHAT') {
      const { appId, appSecret } = config
      const res = await fetch(`${CHANNEL_TEST_URLS.WECHAT}?grant_type=client_credential&appid=${appId}&secret=${appSecret}`)
      const data = await res.json()
      return NextResponse.json(data.access_token ? { success: true, message: '微信连接成功' } : { success: false, message: data.errmsg })
    }
    return NextResponse.json({ success: true, message: '配置已保存' })
  } catch (e: any) {
    return NextResponse.json({ success: false, message: `连接失败: ${e.message}` })
  }
}