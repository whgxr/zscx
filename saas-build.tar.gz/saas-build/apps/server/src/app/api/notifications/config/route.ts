import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function GET() {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ message: '未登录' }, { status: 401 })
  const configs = await prisma.notificationConfig.findMany({ where: { tenantId: user.tenantId } })
  const channels = [
    { name: 'WECOM', label: '企业微信' }, { name: 'DINGTALK', label: '钉钉' },
    { name: 'FEISHU', label: '飞书' }, { name: 'WECHAT', label: '微信' },
    { name: 'EMAIL', label: '邮件' },
  ].map(ch => {
    const cfg = configs.find((c: { channel: string }) => c.channel === ch.name)
    return { ...ch, isEnabled: cfg?.isEnabled || false, config: cfg?.config || null }
  })
  return NextResponse.json({ channels })
}

export async function PUT(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const { channel, isEnabled, config } = await req.json()
  await prisma.notificationConfig.upsert({
    where: { tenantId_channel: { tenantId: user.tenantId, channel } },
    create: { tenantId: user.tenantId, channel, isEnabled, config },
    update: { isEnabled, config },
  })
  return NextResponse.json({ success: true })
}