import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { comparePassword, generateToken, setTokenCookie } from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json()
    if (!username || !password) {
      return NextResponse.json({ message: '请输入用户名和密码' }, { status: 400 })
    }
    const user = await prisma.user.findUnique({
      where: { username },
      include: { role: true, tenant: true },
    })
    if (!user || user.status !== 'ACTIVE') {
      return NextResponse.json({ message: '用户名或密码错误' }, { status: 401 })
    }
    const valid = await comparePassword(password, user.passwordHash)
    if (!valid) {
      return NextResponse.json({ message: '用户名或密码错误' }, { status: 401 })
    }
    const token = generateToken({
      userId: user.id, username: user.username, roleId: user.roleId, tenantId: user.tenantId,
    })
    setTokenCookie(token)
    return NextResponse.json({
      user: { id: user.id, username: user.username, realName: user.realName, role: user.role, tenant: user.tenant },
      token,
    })
  } catch (e) {
    console.error('Login error:', e)
    return NextResponse.json({ message: '登录失败' }, { status: 500 })
  }
}