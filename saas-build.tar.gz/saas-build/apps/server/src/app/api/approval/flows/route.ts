import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ message: '未登录' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const tableId = searchParams.get('tableId')
  const flows = await prisma.approvalFlow.findMany({
    where: { tenantId: user.tenantId, ...(tableId ? { tableId: parseInt(tableId) } : {}) },
    include: { steps: { orderBy: { stepOrder: 'asc' } }, table: { select: { id: true, name: true, label: true } } },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ flows })
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user || user.role?.name !== 'ADMIN') return NextResponse.json({ message: '无权限' }, { status: 403 })
  const { tableId, name, steps } = await req.json()
  if (!tableId || !name) return NextResponse.json({ message: '参数不完整' }, { status: 400 })
  const flow = await prisma.approvalFlow.create({
    data: {
      tenantId: user.tenantId, tableId, name,
      steps: { create: steps.map((s: any, i: number) => ({ stepOrder: i + 1, approverType: s.approverType, approverId: s.approverId || null, approverRole: s.approverRole || null })) },
    },
    include: { steps: { orderBy: { stepOrder: 'asc' } } },
  })
  return NextResponse.json({ flow })
}