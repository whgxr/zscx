import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function POST(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ message: '未登录' }, { status: 401 })
  const { recordId, action, comment } = await req.json()
  if (!recordId || !action) return NextResponse.json({ message: '参数不完整' }, { status: 400 })

  const record = await prisma.dataRecord.findUnique({
    where: { id: recordId },
    include: { approvalFlow: { include: { steps: { orderBy: { stepOrder: 'asc' } } } }, creator: true, table: true },
  })
  if (!record || record.tenantId !== user.tenantId) return NextResponse.json({ message: '记录不存在' }, { status: 404 })

  await prisma.approvalRecord.create({
    data: { recordId, stepId: record.approvalFlow?.steps[record.currentStep || 0]?.id || 0, approverId: user.id, action, comment: comment || null },
  })

  let newStatus = record.status
  if (action === 'APPROVED') {
    const totalSteps = record.approvalFlow?.steps.length || 0
    const nextStep = (record.currentStep || 0) + 1
    if (nextStep >= totalSteps) newStatus = 'REVIEWED'
  } else if (action === 'REJECTED') {
    newStatus = 'REJECTED'
  } else if (action === 'RETURNED') {
    newStatus = 'DRAFT'
  }

  await prisma.dataRecord.update({
    where: { id: recordId },
    data: { status: newStatus as any, currentStep: action === 'APPROVED' ? (record.currentStep || 0) + 1 : record.currentStep },
  })

  return NextResponse.json({ success: true })
}