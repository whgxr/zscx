import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getCurrentUser()
  if (!user) return NextResponse.json({ message: '未登录' }, { status: 401 })
  const records = await prisma.dataRecord.findMany({
    where: {
      tenantId: user.tenantId, status: 'SUBMITTED',
      approvalFlow: { steps: { some: { approverId: user.id } } },
    },
    include: {
      table: { select: { id: true, name: true, label: true } },
      creator: { select: { id: true, realName: true } },
      approvalFlow: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ records })
}