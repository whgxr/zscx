import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { cookies, headers } from 'next/headers'
import { prisma } from './prisma'

const JWT_SECRET = process.env.JWT_SECRET as string

if (!JWT_SECRET) {
  console.error('[FATAL] JWT_SECRET environment variable is required. Set it before starting the application.')
  process.exit(1)
}
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d'

export interface JwtPayload {
  userId: number; username: string; roleId: number; tenantId: number
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export function generateToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN } as any)
}

export function verifyToken(token: string): JwtPayload | null {
  try { return jwt.verify(token, JWT_SECRET) as JwtPayload }
  catch { return null }
}

export async function getCurrentUser() {
  const cookieStore = cookies()
  let token = cookieStore.get('token')?.value
  if (!token) {
    const headerStore = headers()
    const authHeader = headerStore.get('authorization')
    if (authHeader?.startsWith('Bearer ')) token = authHeader.substring(7)
  }
  if (!token) return null
  const payload = verifyToken(token)
  if (!payload) return null
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    include: { role: true, tenant: true, department: true },
  })
  if (!user || user.status !== 'ACTIVE') return null
  return user
}

export function setTokenCookie(token: string) {
  const cookieStore = cookies()
  cookieStore.set('token', token, {
    httpOnly: true, secure: false, sameSite: 'lax', path: '/', maxAge: 7 * 24 * 60 * 60,
  })
}

export function clearTokenCookie() {
  const cookieStore = cookies()
  cookieStore.delete('token')
}