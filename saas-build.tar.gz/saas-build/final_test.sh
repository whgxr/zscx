#!/bin/sh
echo "=== Web Status ==="
curl -s -o /dev/null -w "Status: %{http_code}\n" http://localhost:3002/

echo "=== H5 Status ==="
curl -s -o /dev/null -w "Status: %{http_code}\n" http://localhost:3003/

echo "=== Web API Proxy ==="
curl -s -X POST http://localhost:3002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' | head -c 200

echo ""
echo "=== Docker PS ==="
cd /vol3/1000/docker/zscx-saas/saas-build && docker compose -f docker-compose.yml ps