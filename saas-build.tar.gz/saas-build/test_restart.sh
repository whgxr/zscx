#!/bin/sh
echo "=== Restarting services ==="
cd /vol3/1000/docker/zscx-saas/saas-build && docker compose -f docker-compose.yml up -d

echo ""
echo "=== Login API ==="
curl -s -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

echo ""
echo "=== Web ==="
curl -s -o /dev/null -w "Status: %{http_code}\n" http://localhost:3002/

echo "=== H5 ==="
curl -s -o /dev/null -w "Status: %{http_code}\n" http://localhost:3003/